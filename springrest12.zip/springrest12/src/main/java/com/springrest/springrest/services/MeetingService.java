package com.springrest.springrest.services;

import java.util.List;

import com.springrest.springrest.entities.Meeting;

public interface MeetingService {
	public List<Meeting> meetingdetails();

}
